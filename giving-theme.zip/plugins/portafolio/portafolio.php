<?php 
/*
Plugin Name: puglin custom post
Plugin URI:
Description: Publigin para agregar portafolio al alyout
Version: 1.0
Author: David gonzalez
Author URI:
Licence:
*/

function post_portafolio(){
	$labels = array(
       'name'              => _x('portafolio', 'Giving-theme'),
       'singular_name'     => _x('portafolio', 'post type singular name', 'Giving-theme'),
       'menu_name'         => _x('portafolio', 'admin menu', 'Giving-theme'),
       'name_admin_bar'    => _x('portafolio', 'add new on admin bar', 'Giving-theme'),
       'add_new'           => _x('añadir nueva', 'book', 'Giving-theme'),
       'add_new_item'      => __('añadir nuevo item', 'Giving-theme'),
       'new_item'          => __('nuevo item', 'Giving-theme'),
       'edit_item'         => __('editar item', 'Giving-theme'),
       'view_item'         => __('ver item', 'Giving-theme'),
       'all_items'         => __('todos los items', 'Giving-theme'),
       'search_items'      => __('buscar items', 'Giving-theme'),
       'parent_item_colon' => __('parent items' ,'Giving-theme'),
       'not_found'         => __('no se an encontrados items', 'Giving-theme'),
       'not_found_in_trash'=> __('no se encontraron items en la papelera', 'Giving-theme')
	);

	$args = array(
		'labels'         => $labels,
		'description'    => __('description.', 'Giving-theme'),
		'public'         => true,
		'publicly_queryable' =>true,
		'show_ui'        => true,
		'show_in_menu'        => true,
		'query_var'        => true,
		'rewrite'         => array('slug' => 'portafolio'),
		'capability_type' =>'post',
		'has_archive'     => true,
		'hierarchical'    => false,
		'menu_position'  =>4,
		'supports'       => array('title', 'editor', 'thumbnail'),
		'taxonomies'     => array('category', 'post_tag'),

	);
	register_post_type('portafolio', $args);
}

add_action('init', 'post_portafolio');


function wptutsplus_theme_support() {

add_theme_support( 'post-thumbnails' );


}

add_action('after_setup_theme', 'wptutsplus_theme_support' );


function imagenes_especiales(){
	add_image_size('portafolio', 350, 250, false);

}

add_action('after_setup_theme', 'imagenes_especiales');







?>

