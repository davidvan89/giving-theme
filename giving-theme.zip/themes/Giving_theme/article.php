<?php wp_article();  ?>
<article class="article_img">
	
	<img src="<?php echo get_stylesheet_directory_uri() ?> /img/libro.webp" >
</article>