<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<?php wp_head();  ?>
</head>
<body>

	<header>
		<input type="checkbox"  id="btn-menu">
		<label for="btn-menu">
			<img  src="<?php echo get_stylesheet_directory_uri() ?> /img/iconos/hb.png" width="20px"  >
		</label>

		<nav class="menu">
			<?php 
			   wp_nav_menu(array(
			   	  'theme_location' => 'menu_principal',
			   	  'container_class' => '',
			   	  'container_id' => 'navbar',
			   	  'menu_class' => ' '
			   ));
		    ?>
		</nav>
	</header>
	<hr>
	<div class="c_c">
		<div class="container_single_post">
			<div class="single-post">
				<h4 class="text_single_post">SINGLE POST</h4>
				<nav class="menu_single_post">
					<?php 
				   wp_nav_menu(array(
				   	  'theme_location' => 'menu_single_post',
				   	  'container_class' => '',
				   	  'container_id' => 'navbar_single_post',
				   	  'menu_class' => ' '
				   ));
			    ?>
				</nav>
			</div>
		</div>
	</div>
	




   









	
