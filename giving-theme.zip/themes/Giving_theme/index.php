<?php 
/*Template Name: portafolio*/

/**
*@package giving_theme 

*/
?>



<?php get_header(); ?>


<h1 class="text_p">PORTFOLIO</h1>
<div class="content_portafolio">
	<div class="caja_portafolio">
			
				<?php while (have_posts()) : the_post(); ?>
				
					<?php 
					    $argumentos = array(
					    	'post_type' => 'portafolio',
					    	'post_per_page' => -1,
					    	'orderby' => 'date',
					    	'order' => 'DESC',

					    );

					    $portafolio = new WP_Query($argumentos);
                    ?>
					    
					    <?php while($portafolio->have_posts()) : $portafolio->the_post();  ?>
					    <div>	
					    	  <?php the_post_thumbnail('portafolio'); ?>
					    
                            
					    	<?php the_title('<p class="titulos_portafolio">', '</p>'); ?>
					    	
					    	<?php the_excerpt(); ?>
                       </div>
					    <?php endwhile; wp_reset_postdata(); ?>
				
				<?php endwhile; ?>
				
					

			<!--get_sidebar(); -->
	</div>
</div>

<?php get_footer(); ?>