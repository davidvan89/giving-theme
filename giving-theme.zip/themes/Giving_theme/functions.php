<?php 



function Giving_theme_styles(){

    wp_enqueue_style('normalize', get_stylesheet_directory_uri() . '/css/normalize.css');

    wp_enqueue_style('bootstrap', "https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css");
    wp_enqueue_style('style', get_stylesheet_uri());

    wp_enqueue_script('jquery');

    wp_enqueue_script("bootstrapjs", "https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js", array('jquery'), '4.5.2', true);

}

add_action('wp_enqueue_scripts', 'Giving_theme_styles');


/** navegacion*/

register_nav_menus( array(
	'menu_principal' => __('menú principal', 'Giving-theme'),
	'menu_single_post' => __('menu single post', 'Giving-theme')






));



// Recuperamos todas las páginas que utilizan la plantilla "no-sidebar-page.php".





?>