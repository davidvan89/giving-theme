<footer>
	<div class="footer_container_left">
		<p>ALL RESERVED <span style="color:cyan;">WPDNA</span></p>
	</div>
	<div class="footer_container_right">
		<img src="<?php echo get_stylesheet_directory_uri() ?> /img/iconos/redes1.png" >
		<img src="<?php echo get_stylesheet_directory_uri() ?> /img/iconos/redes2.png" >
		<img src="<?php echo get_stylesheet_directory_uri() ?> /img/iconos/redes3.png" >
		<img src="<?php echo get_stylesheet_directory_uri() ?> /img/iconos/redes4.png" >
		<img src="<?php echo get_stylesheet_directory_uri() ?> /img/iconos/redes5.png" >
		
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>