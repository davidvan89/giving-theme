<?php get_header(); ?>

<article class="article_container">
	<aside  class="content content_search">
		<div class="search">
			<div class="search-container">
				<h6>SEARCHS</h6>
				<hr>
				<input type="" name="buscar" placeholder="buscar" class="buscar">
				<img class="icono_buscar" src="<?php echo get_stylesheet_directory_uri() ?> /img/iconos/busqueda.png">
			</div>
		</div>
		<div class="etiquetas">
			<div class="search-container">
			  <h6>TAGS</h6>
			    <hr>
			    <div class="botones">
			    	<button class="tag">tags1</button>
				    <button class="tag">tags1</button>
				    <button class="tag">tags1</button>
				    <button class="tag">tags1</button>
				    <button class="tag">tags1</button>
			    </div>
			    
			</div>
		</div>
		<div class="categorias">
			<div class="search-container">
				<h6>BLOG CATEGORIES</h6>
			    <hr>
			    <br>
			    <p class="text_categorias">Lighting <span>(5)</span></p>
			    <hr>
			    <br>
			    <p class="text_categorias">Lighting <span>(7)</span></p>
			    <hr>
			    <br>
			    <p class="text_categorias">Lighting <span>(2)</span></p>
			    <hr>
			    <br>
			    <p class="text_categorias">Lighting <span>(15)</span></p>
			    <hr>
			    <br>
			    <p class="text_categorias">Lighting <span>(22)</span></p>
			    <hr>
			    <br>
			    <p class="text_categorias">Lighting <span>(11)</span></p>
			    <br>
			</div>
		</div>

		<div class="recientes">
			<div class="search-container">
			  <h6>RESENT POST</h6>
			    <hr>
			    <div class="campos">
			    	<div class="post-1">
			    		<img src="<?php echo get_stylesheet_directory_uri() ?> /img/casa.png" width="80px" height="80px">
			    		<p class="title-post"><br>SIMPLE POST TITLE <br>
			    			<span>Lorem ipsum dolr sit amet..</span>
			    		</p>
			    	</div>
			    	<div class="post-1">
			    		<img src="<?php echo get_stylesheet_directory_uri() ?> /img/casa.png" width="80px" height="80px">
			    		<p class="title-post"><br>SIMPLE POST TITLE <br>
			    			<span>Lorem ipsum dolr sit amet..</span>
			    		</p>
			    	</div>
			    	<div class="post-1">
			    		<img src="<?php echo get_stylesheet_directory_uri() ?> /img/casa.png" width="80px" height="80px">
			    		<p class="title-post"><br>SIMPLE POST TITLE <br>
			    			<span>Lorem ipsum dolr sit amet..</span>
			    		</p>
			    	</div>
			    </div>
			    
			</div>
		</div>
	</aside>
	

	
		
	
	<div class="content content_article">
		<div class="cp">
			<img id="img_p" src="<?php echo get_stylesheet_directory_uri() ?> /img/libro.webp" >
			<div class="padding">
				<h6 class="title1">LOREM IPSUM DOLOR CONSECTETUR</h6>
				<span class="icon_span">
					<img  src="<?php echo get_stylesheet_directory_uri() ?> /img/iconos/reloj.png" width="15px"  >
				   April 26,2015 </span>
				<span class="icon_span">
					<img  src="<?php echo get_stylesheet_directory_uri() ?> /img/iconos/corazon.png" width="15px"  >
				    12 Likes 
				</span>
				<span class="icon_span">
					<img  src="<?php echo get_stylesheet_directory_uri() ?> /img/iconos/bandera.png" width="15px"  >
				    Branding, UX Desing
				</span>
				<p class="text">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</p>
				<ul class="list">
					<li >LOREM IPSUM DOLOR CONSECTETUR</li>
					<li >LOREM IPSUM DOLOR CONSECTETUR</li>
					<li >LOREM IPSUM DOLOR CONSECTETUR</li>

				</ul>
				<h6 class="title2">LOREM IPSUM DOLOR CONSECTETUR</h6>
				<p class="text">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</p>
				<p class="text2">
					<b>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
					consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
					cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
					proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</b>
				</p>
				<div class="codigo">
					<pre>
						<code class="code">
.some-style { 
         font-size:24px; 
	    font-weight:500px; 
	      margin-bottom:15px; 
	     display: inline-block; 
	     position: relative; 
}
					</code>
					</pre>
					
				</div>
				<p class="text3">
					<b>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
					tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
					</b>
				</p>
			</div>
		</div>
		
		<article class="comentarios">
	<h6 class="title4">HAVE 3 COMMENTS</h6>
	<div class="comentario1">
		<img  src="<?php echo get_stylesheet_directory_uri() ?> /img/avatar.jpg" width="100px"  >
		<p class="text_comentarios">jhon cena<br>
			<span class="comentario_fecha1"> july 15 2015 at 2:39am</span>
			<br><br>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit.
	</div>
	<div class="comentario2">
		<img  src="<?php echo get_stylesheet_directory_uri() ?> /img/avatar.jpg" width="100px"  >
		<p class="text_comentarios">jhon cena<br>
			<span class="comentario_fecha1"> july 15 2015 at 2:39am</span>
			<br><br>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit.
		</p>
	</div>
	<div class="comentario3">
		<img  src="<?php echo get_stylesheet_directory_uri() ?> /img/avatar.jpg" width="100px"  >
		<p class="text_comentarios">jhon cena<br>
			<span class="comentario_fecha1"> july 15 2015 at 2:39am</span>
			<br><br>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit.
		</p>
	</div>
</article>

<article id="formulario">
	<h6 class="title4">LEAVY YOUR THOUGHT</h6>
	<hr>
	<div class="content_formulario">
	<form action="" method="post">
	   	   <input type="text" id="name" name="user_name" placeholder="Name">
	    
	    <input type="email" id="mail" name="user_mail" placeholder="Email">
    <p class="text3">text-area</p>
    <textarea id="msg" name="user_message"></textarea>
 <input type="submit" name="POST COMMENTS" class="enviar">
</form>
	</div>
	
</article>

	</div>	
</article>



<?php get_footer(); ?>